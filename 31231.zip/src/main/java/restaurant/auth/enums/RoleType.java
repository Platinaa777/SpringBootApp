package restaurant.auth.enums;

public class RoleType {

    public static String Admin = "Admin";
    public static String Client = "Client";
}
