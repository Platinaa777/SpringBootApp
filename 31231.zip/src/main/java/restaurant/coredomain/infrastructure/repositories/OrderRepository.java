package restaurant.coredomain.infrastructure.repositories;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import restaurant.coredomain.domain.entities.Dish;
import restaurant.coredomain.domain.entities.Order;
import restaurant.coredomain.domain.repositories.IOrderRepository;
import restaurant.infrastructure.connfactories.NpgsqlConnectionFactory;
import restaurant.infrastructure.connfactories.SqlDishStatements;
import restaurant.infrastructure.connfactories.SqlOrderStatements;
import restaurant.infrastructure.interfaces.IDbConnectionFactory;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Component
@Scope(value = "prototype")
public class OrderRepository implements IOrderRepository {
   private final IDbConnectionFactory<Connection> factory;

    public OrderRepository(IDbConnectionFactory<Connection> factory) {
        this.factory = factory;
    }

    @Override
    public Long add(Order order) {
        var connection = factory.getConnection();

        try {
            var sqlStatement = connection.prepareStatement(SqlOrderStatements.sqlAddOrder);

            sqlStatement.setString(1, order.getTransactionId());
            sqlStatement.setString(2, order.getStatus());

            var result = sqlStatement.executeQuery();
            result.next();
            var id = result.getLong("id");

            // one row was affected
            return id != 0 ? id : null;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean remove(Long id)
    {
        var connection = factory.getConnection();

        try {
            var sqlStatement = connection.prepareStatement(SqlOrderStatements.sqlRemoveOrder);

            sqlStatement.setLong(1, id);

            var result = sqlStatement.executeUpdate();

            return result == 1;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public Order findOrder(String transactionId)
    {
        var connection = factory.getConnection();

        try {
            var sqlStatement = connection.prepareStatement(SqlOrderStatements.sqlFindOrdersOwnToClient);

            sqlStatement.setString(1, transactionId);

            var result = sqlStatement.executeQuery();


            result.next() ;
            var order = Order.builder()
                    .id(result.getLong("id"))
                    .transactionId(result.getString("transaction_id"))
                    .status(result.getString("status"))
                    .build();



            return order;
        } catch (SQLException e) {
            // e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean updateOrderStatus(Long id, String status) {
        var connection = factory.getConnection();

        try {
            var sqlStatement = connection.prepareStatement(SqlOrderStatements.sqlUpdateOrder);

            sqlStatement.setString(1, status);
            sqlStatement.setLong(2, id);

            var result = sqlStatement.executeUpdate();

            return result == 1;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
}
