package restaurant.coredomain.api.controllers;

import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import restaurant.auth.http.models.request.LoginRequest;
import restaurant.auth.services.AuthService;
import restaurant.coredomain.application.commands.order.CreateOrder;
import restaurant.coredomain.application.services.CreateOrderHandler;
import restaurant.coredomain.http.models.order.requests.CreateOrderRequest;
import restaurant.coredomain.http.models.order.requests.RemoveOrderRequest;

@Controller
@RequestMapping("/order")
@Scope(value = "prototype")
public class OrderController {

    private final CreateOrderHandler createOrderHandler;
    private final AuthService authService;

    public OrderController(CreateOrderHandler createOrderHandler, AuthService authService) {
        this.createOrderHandler = createOrderHandler;
        this.authService = authService;
    }

    @PostMapping
    public ResponseEntity<String> createOrder(@RequestBody CreateOrderRequest createOrderRequest) {
        if (createOrderRequest.getTransactionId().isEmpty()) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }

        var authResponse = authService.login(new LoginRequest(
                createOrderRequest.getClientEmail(),
                createOrderRequest.getPassword()));

        if (authResponse == null || !authResponse.isAuthenticated())
            return new ResponseEntity<>(null, HttpStatus.UNAUTHORIZED);


        var response = createOrderHandler.createOrder(CreateOrder.builder()
                .clientEmail(createOrderRequest.getClientEmail())
                .dishes(createOrderRequest.getDishes())
                .transactionId(createOrderRequest.getTransactionId())
                .build());

        if (response.isSuccess) {
            return new ResponseEntity<>("OK! Order was created", HttpStatus.OK);
        }
        return new ResponseEntity<>(String.join("\n", response.errors), HttpStatus.BAD_REQUEST);
    }

    @DeleteMapping
    public ResponseEntity<String> removeOrder(@RequestBody RemoveOrderRequest req) {
        var authResponse = authService.login(new LoginRequest(
                req.getEmail(),
                req.getPassword()));

        if (authResponse == null || !authResponse.isAuthenticated())
            return new ResponseEntity<>(null, HttpStatus.UNAUTHORIZED);

        var response = createOrderHandler.cancelOrder()
    }


}
