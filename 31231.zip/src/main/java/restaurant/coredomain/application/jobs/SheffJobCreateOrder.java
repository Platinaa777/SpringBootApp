package restaurant.coredomain.application.jobs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.springframework.context.annotation.Scope;
import restaurant.coredomain.domain.entities.Dish;
import restaurant.coredomain.domain.entities.Order;
import restaurant.coredomain.domain.entities.enums.OrderType;
import restaurant.coredomain.domain.repositories.IOrderRepository;
import restaurant.coredomain.domain.repositories.IUnitOfWork;
import restaurant.infrastructure.dbrelationships.DishOrderConnector;

import java.util.ArrayList;
import java.util.List;


@Data
@Builder
@AllArgsConstructor
@Scope(value = "prototype")
public class SheffJobCreateOrder implements Runnable {
    private final IOrderRepository orderRepository;
    private final DishOrderConnector dishOrderConnector;
    private final IUnitOfWork unitOfWork;
    private final List<Dish> dishes;
    private final String transactionId;

    @Override
    public void run() {
        unitOfWork.startTransaction();

        Long maxSleep = 1L;
        List<Long> orderIds = new ArrayList<>();
        var orderId = orderRepository
                .add(Order.builder()
                        .transactionId(transactionId)
                        .status(OrderType.COOKING)
                        .build());

        for (var dish : dishes) {
            dishOrderConnector.createConnectedRow(dish.getId(), orderId);

            if (orderId == null) {
                System.out.println("order was failed");
                unitOfWork.rollback();
                return;
            }

            maxSleep = Math.max(maxSleep, dish.getDurationSeconds());
        }

        try {
            Thread.sleep(maxSleep * 1000);
        } catch (Exception ignored) {
            unitOfWork.rollback();
            return;
        }
        var result = orderRepository.updateOrderStatus(orderId, OrderType.COMPLETE);

        if (result) {
            System.out.println("Sheff was done his job, order_id = " + orderId);
            unitOfWork.commit();
        } else {
            unitOfWork.rollback();
        }
    }
}
