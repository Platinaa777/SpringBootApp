package restaurant.coredomain.application.services;


import lombok.AllArgsConstructor;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import restaurant.coredomain.application.commands.order.AppendDishOrder;
import restaurant.coredomain.application.commands.order.CreateOrder;
import restaurant.coredomain.application.commands.sheff.SheffOrder;
import restaurant.coredomain.application.responses.ResponseType;
import restaurant.coredomain.domain.entities.Dish;
import restaurant.coredomain.domain.entities.enums.TransactionType;
import restaurant.coredomain.domain.repositories.IDishRepository;
import restaurant.coredomain.domain.repositories.IOrderRepository;
import restaurant.coredomain.domain.repositories.ITransactionRepository;
import restaurant.coredomain.domain.repositories.IUnitOfWork;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
@Scope(value = "prototype")
public class CreateOrderHandler {

    private final ITransactionRepository transactionRepository;
    private final IOrderRepository orderRepository;
    private final IDishRepository dishRepository;
    private final IUnitOfWork unitOfWork;
    private final SheffService sheffService;

    public ResponseType createOrder(CreateOrder order) {

        // check if transaction was not finished
        var transaction = transactionRepository.find(order.getTransactionId());
        if (transaction != null && transaction.getStatus().equals(TransactionType.FINISHED))
            return new ResponseType(ResponseType.ErrorWithTransaction, false);

        // if user did not buy, we will create shopping transaction
        unitOfWork.startTransaction();
        var transactionId = "";
        if (transaction == null) {
            transactionId = transactionRepository.create(order.getClientEmail());
        } else {
            transactionId = transaction.getId();
        }

        // was thrown exception
        if (transactionId == null) {
            unitOfWork.rollback();
            return new ResponseType(ResponseType.ErrorWithTransaction, false);
        }

        // find all dishes in stock
        List<Dish> dishes = new ArrayList<>();
        for (var clientOrder : order.getDishes()) {
            var dish = dishRepository.findByTitle(clientOrder.getTitle());

            // we can not find one dish in order => cancel the order
            if (dish == null) {
                unitOfWork.rollback();
                return new ResponseType(ResponseType.DishNotFoundWithName(clientOrder.getTitle()), false);
            }

            // have less amount that required
            if (dish.getAmount() < clientOrder.getAmount()) {
                unitOfWork.rollback();
                return new ResponseType(ResponseType.AmountError(clientOrder.getTitle()), false);
            }

            dish.setAmount(dish.getAmount() - clientOrder.getAmount());
            // reserve our amount dish for sheff
            // if null: cant update dish amount because another thread changed the amount in database level
            if (dishRepository.update(dish) == null) {
                unitOfWork.rollback();
                return new ResponseType(ResponseType.ErrorWhileUpdatingAmount(clientOrder.getTitle()), false);
            }

            dishes.add(dish);
        }

        sheffService.acceptOrderToCook(SheffOrder.builder()
                .dishes(dishes)
                .transactionId(transactionId)
                .build());

        unitOfWork.commit();

        return new ResponseType(ResponseType.OrderCreated + "with id = " + transactionId, true);
    }

    public boolean cancelOrder(long orderId, String transactionId) {
        var order = orderRepository.findOrder(transactionId);

        if (order.getId() == orderId) {
            orderRepository.remove(orderId);
            return true;
        }

        return false;
    }

    public ResponseType appendDishToOrder(AppendDishOrder order) {
        var transaction = transactionRepository.find(order.getTransactionId());
        if (transaction != null && transaction.getStatus().equals(TransactionType.FINISHED))
            return new ResponseType(ResponseType.ErrorWithTransaction, false);

        var dish = dishRepository.findByTitle(order.getTitle());

        if (dish == null)
            return new ResponseType(ResponseType.DishNotFoundWithName(order.getTitle()), false);

        var foundOrder = orderRepository.findOrder(order.getEmail());

        if (foundOrder == null)
            return new ResponseType(ResponseType.OrderDoesNotExist(order.getEmail()), false);

        sheffService.appendDishToOrder(dish, foundOrder.getId(), order.getTransactionId());

        return new ResponseType(ResponseType.OrderAppended, true);
    }
}
