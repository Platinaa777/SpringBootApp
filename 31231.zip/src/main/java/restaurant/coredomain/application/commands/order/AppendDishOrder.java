package restaurant.coredomain.application.commands.order;

import lombok.Data;

@Data
public class AppendDishOrder {
    private String title;
    private Long amount;
    private String email;
    private String transactionId;
}
