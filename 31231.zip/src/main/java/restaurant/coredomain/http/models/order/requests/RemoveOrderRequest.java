package restaurant.coredomain.http.models.order.requests;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RemoveOrderRequest {
    private String dishName;
    private String email;
    private String password;
}
