package restaurant.coredomain.domain.entities.enums;

public class OrderType {
    public static String COMPLETE = "COMPLETE";
    public static String COOKING = "COOKING";
}
