package restaurant.coredomain.domain.entities.enums;

public class TransactionType {
    public static String IN_PROGRESS = "IN_PROGRESS";
    public static String FINISHED = "FINISHED";

}