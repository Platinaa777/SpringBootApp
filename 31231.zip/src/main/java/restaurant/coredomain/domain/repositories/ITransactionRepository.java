package restaurant.coredomain.domain.repositories;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import restaurant.coredomain.domain.entities.Transaction;

@Component
@Scope(value = "prototype")
public interface ITransactionRepository {
    String create(String email);
    boolean close(String id);
    Transaction find(String id);
}
