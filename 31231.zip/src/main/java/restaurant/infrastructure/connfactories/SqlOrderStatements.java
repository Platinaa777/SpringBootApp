package restaurant.infrastructure.connfactories;

public class SqlOrderStatements {
    public static String sqlAddOrder = "INSERT INTO orders (transaction_id, status) VALUES (?, ?) RETURNING id;";
    public static String sqlRemoveOrder = "DELETE FROM orders where id = ?";
    public static String sqlFindOrdersOwnToClient = "SELECT * FROM orders WHERE transaction_id = ? and status = 'COOKING'";
    public static String sqlUpdateOrder = "UPDATE orders SET status = ? WHERE id = ?";
}
