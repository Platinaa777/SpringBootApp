package org.example.restaurantapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
